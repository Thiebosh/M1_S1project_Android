#ifndef AD5764R_H
#define AD5764R_H

#include <inttypes.h>

#define FUNCTION_REGISTER	0x00
#define DATA_REGISTER 	0x10
#define COARSE_GAIN_REGISTER 	0x18
#define FINE_GAIN_REGISTER	0x20
#define OFFSET_REGISTER	0x28

#define DAC_A	0x00
#define DAC_B	0x01
#define DAC_C	0x02
#define DAC_D	0x03
#define DAC_ALL	0x04

#define FUNCTION_REGISTER_NOP 0x00
#define FUNCTION_REGISTER_WRITE 0x01
#define FUNCTION_REGISTER_CLEAR 0x04
#define FUNCTION_REGISTER_LOAD 0x05

#define INDIV_UPDATE 0
#define SIMUL_UPDATE 1

class AD5764R {
protected:
  uint8_t _csPin;
  uint8_t _ldacPin;
  
public:
	AD5764R(uint8_t csPin, uint8_t ldacPin);
	void write(uint8_t, uint8_t, int, uint8_t);
	uint16_t read(uint8_t, uint8_t);
};
                                   


#endif
