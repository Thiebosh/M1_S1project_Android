// B.Stefanelli le 25/11/2019


#include "AD5764R.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <Wire.h>
#include <SPI.h>



//==================================================================================
// AD5764R
//==================================================================================

/*---------------------------------------------------------------------------------
 Set up AD5764R chip select pin and ldac pin
		csPin : chip select pin
		ldacPin: LDAC pin 
---------------------------------------------------------------------------------*/

AD5764R::AD5764R(uint8_t csPin, uint8_t ldacPin):_csPin(csPin), _ldacPin(ldacPin)
{

  pinMode(_csPin, OUTPUT);
  digitalWrite(_csPin, HIGH);         // Disable slave pin CS
 
  pinMode(_ldacPin, OUTPUT);
  digitalWrite(_ldacPin, HIGH);   

}

/*---------------------------------------------------------------------------------
 Write data to AD5764R register
		reg210 : 3 bits to select AD5764R register
		a210 : 3 bits to select destination
		data : data value in 2's complement
		simultaneous: 0 = individual update, 1 =  simultaneous update
---------------------------------------------------------------------------------*/
void AD5764R::write(uint8_t reg210, uint8_t a210, int data, uint8_t simultaneous ) {

SPI.setDataMode(SPI_MODE1);  	// mandatory for AD5764R, see timing diagram on datasheet page 8
 
if (simultaneous) digitalWrite(_ldacPin, HIGH);	// Set correct LDAC value with respect to update mode
else digitalWrite(_ldacPin, LOW);     


digitalWrite(_csPin, LOW);       // Enable slave pin CS

SPI.transfer(reg210 | a210);         // Transfer of 3 bytes with respect to datasheet page 24
SPI.transfer(highByte(data));                            					
SPI.transfer(lowByte(data));                            					
 
digitalWrite(_csPin, HIGH);       // Disable slave pin CS

if (simultaneous) {
	digitalWrite(_ldacPin, LOW);
	digitalWrite(_ldacPin, HIGH);
}
  
SPI.setDataMode(SPI_MODE0);	// Hope that original mode was 0!!
}

/*---------------------------------------------------------------------------------
 WRead data from AD5764R register
		reg210 : 3 bits to select AD5764R register
		a210 : 3 bits to select destination
		data : returned data value in uint16_t format 
		!!! data must be post-processed depending on the register effectively read
---------------------------------------------------------------------------------*/
uint16_t AD5764R::read(uint8_t reg210, uint8_t a210) {
	
uint8_t	recByte1, recByte2, recByte3;
int data=0;

SPI.setDataMode(SPI_MODE1);  	// mandatory for AD5764R, see timing diagram on datasheet page 8
	
digitalWrite(_csPin, LOW);       // Enable slave pin CS

SPI.transfer(0x80|reg210 | a210);         // Transfer of 3 bytes with respect to datasheet page 24
SPI.transfer(highByte(data));                            					
SPI.transfer(lowByte(data));                            					
 
digitalWrite(_csPin, HIGH);       // Disable slave pin CS

digitalWrite(_csPin, LOW);       // Enable slave pin CS

recByte1 = SPI.transfer(0x00);         // Transfer of NOP condition
recByte2 = SPI.transfer(0x00);                           					
recByte3 = SPI.transfer(0x00);                            					
 
digitalWrite(_csPin, HIGH);       // Disable slave pin CS

SPI.setDataMode(SPI_MODE0);	// Hope that original mode was 0!!

return (recByte2 << 8)| recByte3;
	
}