// B.Stefanelli le 25/11/2019


#include "IVsource_v2.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <Wire.h>
#include <SPI.h>



//==================================================================================
// IVsource
//==================================================================================

/*---------------------------------------------------------------------------------
 instantiate IVsource
arguments:
	rackNumber : which base board
	slotNumber: which position in base board 
retruns: nothing		
---------------------------------------------------------------------------------*/

IVsource::IVsource(AD5764R &dac, FM24CL16B &fram, uint8_t slotNumber, uint8_t framAdd): _dac(dac), _fram(fram), _slotNumber(slotNumber)
{
_framAddress = framAdd << 8; // converts into compound address
}

/*---------------------------------------------------------------------------------
 initialize  IVsource
 arguments: none
 retruns: nothing
	
---------------------------------------------------------------------------------*/
 void IVsource::init(void) {
  Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
  Wire.write(MCP23xxx_IODIR);	// port direction output excepted GP2 and GP1
  Wire.write(0x06);
  Wire.endTransmission();
  
  Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
  Wire.write(MCP23xxx_GPPU);
  Wire.write(0x06); // GP1 and GP2 input pull-up
  Wire.endTransmission();
  
  Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
  Wire.write(MCP23xxx_GPIO);
  Wire.write(0x00); 
  Wire.endTransmission();  

_type = 0; // type = V
_onoff = 0; // Off
_portValue = 0x00;
_value = 0;
_range = 0;
_coarseOffset = _fram.readInt(_framAddress + VOLTAGE_MODE_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
_fineOffset = _fram.readInt(_framAddress + VOLTAGE_MODE_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
_coarseGain = 1 + 1e-6*(_fram.readInt(_framAddress + VOLTAGE_MODE_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
_fineGain = _fram.readInt(_framAddress + VOLTAGE_MODE_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	

  switch (_slotNumber) {	
    case 0:
      _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
      //_dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
      break;
    case 1:
      _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
      break;
    case 2:
      _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
    // _dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
      break;
    case 3:
      _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
      break;
    case 4:
      _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
      break;
    case 5:
      _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
    //  _dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
      break;
    case 6:
      _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
      break;
    case 7:
      _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
      break;
  }	// end case
 }
 
/*---------------------------------------------------------------------------------
 set source value
 arguments: 
 value: source value in mV
 retruns: nothing	
---------------------------------------------------------------------------------*/
 void IVsource::setValue(int16_t value){
	 _value = value;	// stores current mV value in protected variable

// updates the corresponding DAC if V mode or (I mode and source on)	 
	 if (!_type || (_type && _onoff)){	
   switch (_slotNumber) {	
    case 0:
      _dac.write(DATA_REGISTER, DAC_A, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);    
      break;
    case 1:
      _dac.write(DATA_REGISTER, DAC_B, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 2:
      _dac.write(DATA_REGISTER, DAC_C, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 3:
      _dac.write(DATA_REGISTER, DAC_D, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 4:
      _dac.write(DATA_REGISTER, DAC_A, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 5:
      _dac.write(DATA_REGISTER, DAC_B, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 6:
      _dac.write(DATA_REGISTER, DAC_C, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 7:
      _dac.write(DATA_REGISTER, DAC_D, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
  }	// end case
	 }	// end if
 }

 /*---------------------------------------------------------------------------------
 get source value
 arguments: none 
 retruns: value: source value in mV	
---------------------------------------------------------------------------------*/
 int16_t IVsource::getValue(void){
	 return _value;
 }
 
/*---------------------------------------------------------------------------------
 Disconnect IVsource (if type = I, reests the current value and then switches relay off )
 arguments: none
 retruns: nothing		 
---------------------------------------------------------------------------------*/
void IVsource::sourceOff(void) {
	
	if(!_type){	// type = V
		_portValue &= ~VSOURCE_ON; 
	} else {	// type = I
	/*
	* modif to avoid current spikes for old IVsource version w/o 6th relay
	* only VDAC is reset, relay remains on
		_portValue &= ~ISOURCE_ON;  
	*/	
	_portValue &= ~0x01; // red led only 
	
	  switch (_slotNumber) {	// resets the corresponding DAC
    case 0:
      _dac.write(DATA_REGISTER, DAC_A, 0 + _coarseOffset, INDIV_UPDATE);    
      break;
    case 1:
      _dac.write(DATA_REGISTER, DAC_B, 0 + _coarseOffset, INDIV_UPDATE);
      break;
    case 2:
      _dac.write(DATA_REGISTER, DAC_C, 0 + _coarseOffset, INDIV_UPDATE);
      break;
    case 3:
      _dac.write(DATA_REGISTER, DAC_D, 0 + _coarseOffset, INDIV_UPDATE);
      break;
    case 4:
      _dac.write(DATA_REGISTER, DAC_A, 0 + _coarseOffset, INDIV_UPDATE);
      break;
    case 5:
      _dac.write(DATA_REGISTER, DAC_B, 0 + _coarseOffset, INDIV_UPDATE);
      break;
    case 6:
      _dac.write(DATA_REGISTER, DAC_C, 0 + _coarseOffset, INDIV_UPDATE);
      break;
    case 7:
      _dac.write(DATA_REGISTER, DAC_D, 0 + _coarseOffset, INDIV_UPDATE);
      break;
  }
	}
	
	// switches the corresponding relay
  Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
  Wire.write(MCP23xxx_GPIO);
  Wire.write(_portValue); 
  Wire.endTransmission();  

	_onoff = 0; // off

}

/*---------------------------------------------------------------------------------
 Connect Vsource or Isource (switches relay on at zero current and then sets the correct current value)
 arguments: none
 retruns: nothing 
---------------------------------------------------------------------------------*/
void IVsource::sourceOn(void){
	
		if(!_type){	// type = V
	_portValue &= ~ISOURCE_ON; // if necessary...
	_portValue |= VSOURCE_ON; 

	Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
	Wire.write(MCP23xxx_GPIO);
	Wire.write(_portValue); 
	Wire.endTransmission(); 
	
		} else { // type = I

	_portValue &= ~VSOURCE_ON; // if necessary...
	/*
	* modif to avoid current spikes for old IVsource version w/o 6th relay
	* only VDAC is reset, relay remains on	
	_portValue |= ISOURCE_ON; 
	*/	
	_portValue |= 0x01;	// green led only 
	
		// switches the corresponding relay with value = 0
	Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
	Wire.write(MCP23xxx_GPIO);
	Wire.write(_portValue); 
	Wire.endTransmission(); 
		}
	
	  switch (_slotNumber) {	// updates the corresponding DAC with current stored value
    case 0:
      _dac.write(DATA_REGISTER, DAC_A, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);    
      break;
    case 1:
      _dac.write(DATA_REGISTER, DAC_B, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 2:
      _dac.write(DATA_REGISTER, DAC_C, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 3:
      _dac.write(DATA_REGISTER, DAC_D, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 4:
      _dac.write(DATA_REGISTER, DAC_A, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 5:
      _dac.write(DATA_REGISTER, DAC_B, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 6:
      _dac.write(DATA_REGISTER, DAC_C, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
    case 7:
      _dac.write(DATA_REGISTER, DAC_D, (int)round(4 * _value * _coarseGain) + _coarseOffset, INDIV_UPDATE);
      break;
  }
		
		
	_onoff =1; // on
	
}

/*---------------------------------------------------------------------------------
 querry source status 
 arguments: none
 return: 0: Off 1:On
---------------------------------------------------------------------------------*/
uint8_t IVsource::isSourceOn(void){
	return _onoff;
}


/*---------------------------------------------------------------------------------
 set Isource range, smooth transition between ranges (i.e. no range is skipped)
  arguments:
	newRange: 0..3 =  range to set
 retruns: nothing
---------------------------------------------------------------------------------*/
void IVsource::setRange(uint8_t newRange){
	uint8_t mask;
	
	if (_range < newRange){	// range is increasing
		while (_range < newRange){
			switch (_range){
				case 0:
				_portValue |= 0x80;	// RL3 on
				break;
				case 1:
				_portValue |= 0x40;	// RL4 on
				break;
				case 2:
				_portValue |= 0x20;	// RL5 on
				break;
				default:
				break;
			}
		
		_range++;

		Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
		Wire.write(MCP23xxx_GPIO);
		Wire.write(_portValue); 
		Wire.endTransmission(); 		

		delay(100); // 1 second for test only, to be reduced to maybe 100ms
		}
		
	} else if (_range > newRange){ // range is decreasing
		while (_range > newRange){
			switch (_range){
				case 3:
				_portValue &= ~0x20;	// RL5 off
				break;
				case 2:
				_portValue &= ~0x40;	// RL4 off
				break;
				case 1:
				_portValue &= ~0x80;	// RL2 off
				break;
				default:
				break;
			}	
			
		_range--;
	
		Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
		Wire.write(MCP23xxx_GPIO);
		Wire.write(_portValue); 
		Wire.endTransmission(); 	

		delay(100); // 1 second for test only, to be reduced to maybe 100ms
		}
		
	} else {} // range is the same , no action
	
	// at this point, _range is updated to its most current value
	
	switch(_range){
		case 0:
		_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE0_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE0_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE0_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
		_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE0_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
		break;

		case 1:
		_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE1_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE1_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE1_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
		_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE1_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
		break;
		
		case 2:
		_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE2_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE2_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE2_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
		_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE2_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
		break;

		case 3:
		_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE3_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE3_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE3_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
		_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE3_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
		break;
			
		default:
		break;
		
	} // end case

  switch (_slotNumber) {	
    case 0:
      _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
      //_dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
      break;
    case 1:
      _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
      //_dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
      break;
    case 2:
      _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
      break;
    case 3:
      _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
      break;
    case 4:
      _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
    //  _dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
      break;
    case 5:
      _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
    //  _dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
      break;
    case 6:
      _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
    //  _dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
      break;
    case 7:
      _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
     // _dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
	  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
      break;
  }	// end case
  
}

/*---------------------------------------------------------------------------------
 get source range
 arguments: none 
 retruns: range: source range (0..3)
---------------------------------------------------------------------------------*/
 uint8_t IVsource::getRange(void){
	 return _range;
 }

/*---------------------------------------------------------------------------------
 set source type
 arguments: 0: Vsource, 1: Isource
 retruns: nothing
---------------------------------------------------------------------------------*/
 void IVsource::setType(uint8_t type){
	 
	if(!type){	// type = V
		_portValue &= ~ISOURCE_ON; // if necessary...
		_type = 0;
		
		_coarseOffset = _fram.readInt(_framAddress + VOLTAGE_MODE_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_fineOffset = _fram.readInt(_framAddress + VOLTAGE_MODE_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
		_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + VOLTAGE_MODE_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
		_fineGain = _fram.readInt(_framAddress + VOLTAGE_MODE_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	

		  switch (_slotNumber) {	
			case 0:
			  _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
			  break;
			case 1:
			  _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
			  break;
			case 2:
			  _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
			  break;
			case 3:
			  _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
			  break;
			case 4:
			  _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
			  break;
			case 5:
			  _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
			  break;
			case 6:
			  _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
			  break;
			case 7:
			  _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
			  break;
		  }	// end case		
		
		
	} else { // type = I
		_portValue &= ~VSOURCE_ON; // if necessary...
		_portValue |= 0x10;	// relay only, led remains red
		_type = 1;
		
		switch(_range){
			case 0:
			_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE0_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE0_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE0_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
			_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE0_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
			break;

			case 1:
			_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE1_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE1_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE1_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
			_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE1_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
			break;
			
			case 2:
			_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE2_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE2_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE2_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
			_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE2_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
			break;

			case 3:
			_coarseOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE3_COARSE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_fineOffset = _fram.readInt(_framAddress + CURRENT_MODE_RANGE3_FINE_OFFSET_BASE_ADDRESS + 2*_slotNumber);
			_coarseGain = 1+1e-6*(_fram.readInt(_framAddress + CURRENT_MODE_RANGE3_COARSE_GAIN_BASE_ADDRESS + 2*_slotNumber));
			_fineGain = _fram.readInt(_framAddress + CURRENT_MODE_RANGE3_FINE_GAIN_BASE_ADDRESS + 2*_slotNumber);	
			break;
				
			default:
			break;
			
		} // end case
		
		switch (_slotNumber) {	
			case 0:
			  _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
			  //_dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
			  break;
			case 1:
			  _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
			 // _dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
			  break;
			case 2:
			  _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
			  //_dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
			  break;
			case 3:
			  _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
			  //_dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
			  break;
			case 4:
			  _dac.write(OFFSET_REGISTER, DAC_A, _fineOffset, INDIV_UPDATE); 
			  //_dac.write(COARSE_GAIN_REGISTER, DAC_A, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_A,_fineGain, INDIV_UPDATE);   	
			  break;
			case 5:
			  _dac.write(OFFSET_REGISTER, DAC_B, _fineOffset, INDIV_UPDATE); 
			  //_dac.write(COARSE_GAIN_REGISTER, DAC_B, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_B,_fineGain, INDIV_UPDATE);   	
			  break;
			case 6:
			  _dac.write(OFFSET_REGISTER, DAC_C, _fineOffset, INDIV_UPDATE); 
			  //_dac.write(COARSE_GAIN_REGISTER, DAC_C, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_C,_fineGain, INDIV_UPDATE); 
			  break;
			case 7:
			  _dac.write(OFFSET_REGISTER, DAC_D, _fineOffset, INDIV_UPDATE); 
			  //_dac.write(COARSE_GAIN_REGISTER, DAC_D, _coarseGain, INDIV_UPDATE);   
			  _dac.write(FINE_GAIN_REGISTER, DAC_D,_fineGain, INDIV_UPDATE); 
			  break;
		}	// end case

	
		switch (_slotNumber) {	// resets the corresponding DAC
			case 0:
			  _dac.write(DATA_REGISTER, DAC_A, 0 + _coarseOffset, INDIV_UPDATE);    
			  break;
			case 1:
			  _dac.write(DATA_REGISTER, DAC_B, 0 + _coarseOffset, INDIV_UPDATE);
			  break;
			case 2:
			  _dac.write(DATA_REGISTER, DAC_C, 0 + _coarseOffset, INDIV_UPDATE);
			  break;
			case 3:
			  _dac.write(DATA_REGISTER, DAC_D, 0 + _coarseOffset, INDIV_UPDATE);
			  break;
			case 4:
			  _dac.write(DATA_REGISTER, DAC_A, 0 + _coarseOffset, INDIV_UPDATE);
			  break;
			case 5:
			  _dac.write(DATA_REGISTER, DAC_B, 0 + _coarseOffset, INDIV_UPDATE);
			  break;
			case 6:
			  _dac.write(DATA_REGISTER, DAC_C, 0 + _coarseOffset, INDIV_UPDATE);
			  break;
			case 7:
			  _dac.write(DATA_REGISTER, DAC_D, 0 + _coarseOffset, INDIV_UPDATE);
			  break;
		}
		
		
		
	}
	
	delay(100);
	
	Wire.beginTransmission(MCP23xxx_ADDRESS + _slotNumber);
	Wire.write(MCP23xxx_GPIO);
	Wire.write(_portValue); 
	Wire.endTransmission(); 
	
 }
 /*---------------------------------------------------------------------------------
 get source type
 arguments: none 
 retruns: source type, 0: Vsource, 1: Isource
---------------------------------------------------------------------------------*/
 uint8_t IVsource::getType(void){
	 return _type;
 }