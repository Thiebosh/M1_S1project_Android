#ifndef FM24CL16B_H
#define FM24CL16B_H

#include <inttypes.h>

#define PAGE0	0x50
#define PAGE1	0x51
#define PAGE2	0x52
#define PAGE3	0x53
#define PAGE4	0x54
#define PAGE5	0x55
#define PAGE6	0x56
#define PAGE7	0x57



class FM24CL16B {
protected:
  uint8_t _wordCount;
  uint8_t _wordWidth;
  uint8_t _slaveID;
  uint8_t _pageLock;	// 1 bit per page B7 .. B0 -> page7 .. page0
  
public:
	FM24CL16B();
	
	void writeByte(uint8_t, uint8_t, uint8_t);
	void writeInt(uint8_t, uint8_t, int16_t);
	void writeByte(uint16_t, uint8_t);
	void writeInt(uint16_t, int16_t);

	
	uint8_t readByte(uint8_t, uint8_t);
	int16_t readInt(uint8_t, uint8_t);
	uint8_t readByte(uint16_t);
	int16_t readInt(uint16_t);
	
	void blankPage(uint8_t);
	void softPageLock(uint8_t);
	void softPageUnlock(uint8_t);
	uint8_t isPageLocked(uint8_t);
};
                                   


#endif
