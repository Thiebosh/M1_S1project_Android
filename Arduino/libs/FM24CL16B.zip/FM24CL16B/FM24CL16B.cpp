// B.Stefanelli le 25/11/2019


#include "FM24CL16B.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <Wire.h>
#include <SPI.h>



//==================================================================================
// FM24CL16B constructor 
//==================================================================================

/*---------------------------------------------------------------------------------
 Set up FM24CL16B chip 

---------------------------------------------------------------------------------*/

FM24CL16B::FM24CL16B()
{
_wordCount = 2048;
_wordWidth = 8;
_slaveID = 0x50;
_pageLock = 0; // releases all soft locks
  
}

//==================================================================================
// FM24CL16B  write functions
//==================================================================================

/*---------------------------------------------------------------------------------
 Write byte data to FM24CL16B
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)
		address : address in page (0 .. 255)
		data : data value 8bits unsigned
		
---------------------------------------------------------------------------------*/
void FM24CL16B::writeByte(uint8_t pageAdd, uint8_t address, uint8_t data ) {

Wire.beginTransmission(pageAdd); // send page in memory
Wire.write(address); // send address in page 
Wire.write(data); // send data 
Wire.endTransmission();
}

/*---------------------------------------------------------------------------------
 Write byte data to FM24CL16B
		compoundAdd = slaveID (0x50)+ page number (0..7) + address (0..255)
		data : data value 8bits unsigned
		
---------------------------------------------------------------------------------*/
void FM24CL16B::writeByte(uint16_t compoundAdd, uint8_t data ) {

Wire.beginTransmission(highByte(compoundAdd)); // send page in memory
Wire.write(lowByte(compoundAdd)); // send address in page 
Wire.write(data); // send data 
Wire.endTransmission();
}

/*---------------------------------------------------------------------------------
 Write integer data to FM24CL16B
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)
		address : address in page (0 .. 255)
		data : data value 8bits unsigned
		data stored Big Endian
---------------------------------------------------------------------------------*/
void FM24CL16B::writeInt(uint8_t pageAdd, uint8_t address, int16_t data ) {


Wire.beginTransmission(pageAdd); // send page in memory
Wire.write(address); // send address in page 
Wire.write(highByte(data)); // send high nibble of data 
Wire.write(lowByte(data)); // send low nibble of data 
Wire.endTransmission();
}

/*---------------------------------------------------------------------------------
 Write integer data to FM24CL16B
		compoundAdd = slaveID (0x50)+ page number (0..7) + address (0..255)
		data : data value 8bits unsigned
		data stored Big Endian
---------------------------------------------------------------------------------*/
void FM24CL16B::writeInt(uint16_t compoundAdd, int16_t data ) {


Wire.beginTransmission(highByte(compoundAdd)); // send page in memory
Wire.write(lowByte(compoundAdd)); // send address in page 
Wire.write(highByte(data)); // send high nibble of data 
Wire.write(lowByte(data)); // send low nibble of data 
Wire.endTransmission();
}
//==================================================================================
// FM24CL16B read functions
//==================================================================================

/*---------------------------------------------------------------------------------
Read byte data from FM24CL16B
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)
		address : address in page (0 .. 255)
		data : data value 8bits unsigned
		
---------------------------------------------------------------------------------*/
uint8_t FM24CL16B::readByte(uint8_t pageAdd, uint8_t address) {

Wire.beginTransmission(pageAdd); // send page in memory
Wire.write(address); // send address in page  
Wire.endTransmission();

Wire.requestFrom(pageAdd,1);	// request 1 byte 
while (!Wire.available()){}	// wait for availability
return Wire.read();			// read the byte
}

/*---------------------------------------------------------------------------------
Read byte data from FM24CL16B
		compoundAdd = slaveID (0x50)+ page number (0..7) + address (0..255)
		data : data value 8bits unsigned
		
---------------------------------------------------------------------------------*/
uint8_t FM24CL16B::readByte(uint16_t compoundAdd) {

Wire.beginTransmission(highByte(compoundAdd)); // send page in memory
Wire.write(lowByte(compoundAdd)); // send address in page  
Wire.endTransmission();

Wire.requestFrom(highByte(compoundAdd),1);	// request 1 byte 
while (!Wire.available()){}	// wait for availability
return Wire.read();			// read the byte
}

/*---------------------------------------------------------------------------------
Read data from FM24CL16B
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)
		address : address in page (0 .. 255)
		data : data value 16 bits signed
		
---------------------------------------------------------------------------------*/
int16_t FM24CL16B::readInt(uint8_t pageAdd, uint8_t address) {

int16_t val=0;

Wire.beginTransmission(pageAdd); // send page in memory
Wire.write(address); // send address in page  
Wire.endTransmission();

Wire.requestFrom(pageAdd,2);	// request 2 bytes 
while (!Wire.available()){}	// wait for availability
 val |= Wire.read();			//high nibble in the low nibble

val = val<<8;	// high nibble OK

val |= Wire.read();	// appends low nibble
if (val > 32767) return -65536+val;
else return val;
}

/*---------------------------------------------------------------------------------
Read data from FM24CL16B
		compoundAdd = slaveID (0x50)+ page number (0..7) + address (0..255)
		data : data value 16 bits signed
		
---------------------------------------------------------------------------------*/
int16_t FM24CL16B::readInt(uint16_t compoundAdd) {

int16_t val=0;

Wire.beginTransmission(highByte(compoundAdd)); // send page in memory
Wire.write(lowByte(compoundAdd)); // send address in page  
Wire.endTransmission();

Wire.requestFrom(highByte(compoundAdd),2);	// request 2 bytes 
while (!Wire.available()){}	// wait for availability
 val |= Wire.read();			//high nibble in the low nibble

val = val<<8;	// high nibble OK

val |= Wire.read();	// appends low nibble
if (val > 32767) return -65536+val;
else return val;
}

//==================================================================================
// FM24CL16B  other functions
//==================================================================================

/*---------------------------------------------------------------------------------
 Blank FM24CL16B memory page
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)

		
---------------------------------------------------------------------------------*/
void FM24CL16B::blankPage(uint8_t pageAdd) {

for (int i=0; i<256; i++){
Wire.beginTransmission(pageAdd); // send page in memory
Wire.write(i); // send start address in page 
Wire.write(0x00); // write 0x00 
Wire.endTransmission();
}
}

/*---------------------------------------------------------------------------------
 Soft lock FM24CL16B memory page
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)

		
---------------------------------------------------------------------------------*/
void FM24CL16B::softPageLock(uint8_t pageAdd){
	
	_pageLock |= 0x01 << (pageAdd - 0x50);
}

/*---------------------------------------------------------------------------------
 Soft unlock FM24CL16B memory page
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)

		
---------------------------------------------------------------------------------*/
void FM24CL16B::softPageUnlock(uint8_t pageAdd){
	
	_pageLock &= ~(0x01 << (pageAdd - 0x50));
}

/*---------------------------------------------------------------------------------
 Querrie lock status of  FM24CL16B memory page
		pageAdd : page address in memory = slaveID (0x50)+ page number (0..7)
		returns: 0=page unlocked, 1: page locked
		
---------------------------------------------------------------------------------*/
uint8_t FM24CL16B::isPageLocked(uint8_t pageAdd){
	
	if (_pageLock & (0x01 << (pageAdd - 0x50))) return 1;
	else return 0;
}


